﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

//System.IO.Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "file1.txt"));
//Q2. Write a Code to perform File Copy operation.
//You need to accept the source and destination file names.
//The data should be copied from source file to destination file.
//Handle all the exceptions that might occur during the file copy operation.


namespace Lab12Q2
{

    class Program
    {
        // public static string path { get; private set; }
        static void CopyTextFile(string SFilenames, string DFilename)
        {
            //string sourceFile = @"C:\Users\hp\Desktop\sat1\labmanual12question1\labmanual12question2\bin\Debug\file1.txt";
            // string destinationFile = @"C:\Users\hp\Desktop\sat1\labmanual12question1\labmanual12question2\bin\Debug\file2.txt";

            // string path = Path.GetFullPath(FileName);//filename get set
            // string path = MyClass.Path;

            string sourceFile = String.Concat(Path.GetFullPath(SFilenames), ".txt");
            string destinationFile = String.Concat(Path.GetFullPath(DFilename), ".txt");

            try
            {
                File.Copy(sourceFile, destinationFile, true);
                Console.WriteLine("copied");
            }
            catch (IOException iox)
            {
                Console.WriteLine(iox.Message);
            }
        }
        static void Main(string[] args)
        {
            // MyClass myClass = new MyClass();
            Console.WriteLine("Available files: file1 file2 file 3 ");
            Console.WriteLine("Enter Name of Source File:");
            string SFilenames = Console.ReadLine();
            Console.WriteLine("Enter Name of Destination File:");
            string DFilename = Console.ReadLine();

            //if (Convert.ToBoolean(input2.Equals(Filename)))
            //{
            //    Console.WriteLine("****Outputs***");
            //}

            // Console.WriteLine("Output From Text File:");
            // ReadTextFile();
            // var path = Path.Combine(Directory.GetCurrentDirectory(),
            //  
            // myClass.Path = Path.GetFullPath(SFilenames);

            //Console.WriteLine($"{Path.GetFullPath(SFilenames)}, {Path.GetFullPath(DFilename)}");

            CopyTextFile(SFilenames, DFilename);
            Console.ReadKey();

        }
    }


    //public class MyClass
    //{
    //    //private string path;
    //    //public string Path
    //    //{
    //    //    get => path;//cs7expression bodied getter 

    //    //    set => path = value;// cs7expression bodied setter

    //    //}
    //    public string Path { get; set; }
    //   // public int Num1 { get; set; }

    //}
}
