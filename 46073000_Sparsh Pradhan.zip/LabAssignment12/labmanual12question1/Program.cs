﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
//Q1. Write a Code to Read and Display the contents of a text file.
//Accept the name of the file from the user.
//Handle all the exceptions that might occur during reading.
namespace labmanual12question1
{
    class Program
    {
        static void WriteTextFile(string data, string input2)
        {
            // FileStream stream = new FileStream("SampleBinary.txt", FileMode.Create, FileAccess.Write);
            FileStream stream = new FileStream(input2 , FileMode.Create, FileAccess.Write);
            StreamWriter writer = new StreamWriter(stream);
            try
            {
                //Console.WriteLine(true);//
                //Console.WriteLine(DataTime.Now.ToString());
                //Console.WriteLine(1000);
                writer.Write(data);//reads userinput fromt text file & ****puts on console puts******
                writer.Flush();
                //  Console.Flush();//flash select right clivk snippet to move to try block
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                writer.Close();
                writer.Dispose();
                writer.Close();
                writer.Dispose();
            }

        }
        static void ReadTextFile(string input2)
        {
            FileStream stream = new FileStream(input2 , FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(stream);
            try
            {
                //Console.WriteLine(true);//
                //Console.WriteLine(DataTime.Now.ToString());
                //Console.WriteLine(1000);
                string data = reader.ReadToEnd();
                Console.WriteLine(data);
                //  Console.Flash();//flash select right clivk snippet to move to try block
            }
            catch (IOException ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                reader.Close();
                reader.Dispose();
                reader.Close();
                reader.Dispose();
            }

        }
        static void Main(string[] args)
        {
           
            Console.WriteLine("Enter Name of File:");
            string Filename = Console.ReadLine();
            string input2 = Filename;
            
            if(Convert.ToBoolean(input2.Equals(Filename) ))
            {
                Console.WriteLine("****Outputs***");
            }
            Console.WriteLine("Enter Input in File:");
            string input = Console.ReadLine();//user input
            WriteTextFile(input,input2);
            Console.WriteLine("Output From Text File:");
            ReadTextFile(input2);
            Console.ReadKey();

        }
    }
}
