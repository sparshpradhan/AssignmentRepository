﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//This_____________________is______________________Question___________________1

namespace LabAssignment11
{
    public delegate void CreditCardPayment(float i);
    public class CreditCard
    {
        public int CreditCardNo;

        float BalanceAmount = 0;
        readonly float  CreditLimit=10000; 

        public string CardHolderName;

        public event CreditCardPayment CardPay;

        public CreditCard()
        {
            this.CardHolderName = "";
            this.CreditCardNo = 00000000;

        }

        public CreditCard(int _creditcardno, string _cardholdername)
        {
            this.CreditCardNo = _creditcardno;
            this.CardHolderName = _cardholdername;
        }
        public float GetBalance()
        {
            return this.BalanceAmount;
        }

        public float GetCreditLimit()
        {

            return this.CreditLimit;
        }

        public void MakePayment(float paid)
        {
            this.BalanceAmount += paid;
            CardPay.Invoke(paid);
        }

    }

}
