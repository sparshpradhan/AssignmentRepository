﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace LabAssignment11
{
    class Program
    {
        static void Main(string[] args)
        
        
        {
            //Q_U_E_S_T_I_O_N 1
            CreditCard cr = new CreditCard(123456, "James");
            Console.WriteLine($"CardHolder name : {cr.CardHolderName}, CardHolder Number : {cr.CreditCardNo}");

            

            cr.CardPay += new CreditCardPayment(CardPay);
            
            cr.MakePayment(444);

            Console.ReadKey();
        }

         static void CardPay(float payment)
        {
            Console.WriteLine($"You paid amount INR {payment}");

        }







    }


}
