﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab8
{
    class Program
    {


        static void Main(string[] args)
        {
            // Question 1

            Console.WriteLine("Enter the no. of records you wanna add");
            int n = Convert.ToInt32(Console.ReadLine());
            Hashtable ht = new Hashtable(n);
            for (int i = 0; i <= n; i++)
            {
                Console.WriteLine($"Enter the RTO district {i} :");
                string s = Console.ReadLine();
                ht.Add(i, s);


            }
            Console.WriteLine();
            Console.WriteLine("________________");
            ICollection keys = ht.Keys;

            Console.WriteLine("Hashtable:");
            Console.WriteLine();
            foreach (var val in keys)
            {
                Console.WriteLine(val + "-" + ht[val]);
            }
            Console.WriteLine();
            Console.WriteLine("________________");
            Console.WriteLine("Enter the RTO District  you want to search");
            // int k = Convert.ToInt32(Console.ReadLine());
            string k = Console.ReadLine();
            if (ht.ContainsValue(k))
            {
                Console.WriteLine();
                Console.WriteLine("________________");
                Console.WriteLine("The record contains the RTO District ");
            }
            else
            {

                Console.WriteLine();
                Console.WriteLine("________________");
                Console.WriteLine("The record does not contain the RTO Distrct");
            }
            Console.WriteLine($"The count is : {ht.Count}");
            Console.WriteLine("Enter the key of the record you want to remove");
            int M = Convert.ToInt32(Console.ReadLine());
            ht.Remove(M);
            Console.WriteLine("New list after removing an item: ");
            foreach (var key in ht.Keys)
            {
                Console.WriteLine("Key = {0}, Value = {1}", key, ht[key]);

                // Question 2

                Hashtable hashtable = new Hashtable();
                hashtable.Add("Area", 1000);
                hashtable.Add("Perimeter", 55);
                hashtable.Add("Mortgage", 540);



                //Question 2 Task 1
                Console.WriteLine(hashtable.ContainsKey("Perimeter"));

                //Question 2 Task 2
                Console.WriteLine(hashtable.Contains("Area"));
                int value = (int)hashtable["Area"];
                Console.WriteLine($"Area is: {value}");

                //Question 2 Task 3
                hashtable.Remove("Mortgage");



                Console.ReadKey();
            }
        }
    
    }
}
