﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssignment01Q4
{
    class Program
    {
        static void Main(string[] args)
        {
            Student s = new Student(10, "Jen", 34, "FeMale", "asdqwdas", 76, "03/06/1988");

            Console.ReadKey();
        }
    }
}
