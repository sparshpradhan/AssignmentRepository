﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssignment01Q4
{
    class Student
    {
        int rollNo;
        string Nm;
        int age;
        string gender;
        string addr;
        float per;
        string DoB;

        public Student(int RNo, string nm, int Age, string Gen, string Addr, float Per, string dob)
        {
            this.rollNo = RNo;
            this.Nm = nm;
            this.age = Age;
            this.gender = Gen;
            this.addr = Addr;
            this.per = Per;
            this.DoB = dob;

            Console.WriteLine($"RollNo is : {RNo}");
            Console.WriteLine($"Name is : {nm}");
            Console.WriteLine($"Age is : {Age}");
            Console.WriteLine($"Gender is : {Gen}");
            Console.WriteLine($"Address is : {Addr}");
            Console.WriteLine($"Percentage is : {Per}");
            Console.WriteLine($"DoB is : {dob}");
        }
    }
}
