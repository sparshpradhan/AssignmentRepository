﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssignment01Q1Task04
{
    class Program
    {
        static void Main(string[] args)
        {
            new Employee(111, "Sp", "Dombivli", "thane", "tester", 2000);

            Console.ReadKey();
        }
    }
}
