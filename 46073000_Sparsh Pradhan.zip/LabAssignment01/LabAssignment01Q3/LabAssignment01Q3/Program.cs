﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssignment01Q3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number : ");
            int num = Convert.ToInt32(Console.ReadLine());

            switch (num)
            {
                case 1:
                    Console.WriteLine($"Number is 1");
                    break;

                case 2:
                    Console.WriteLine($"Number is 2");
                    break;

                case 3:
                    Console.WriteLine($"Number is 3");
                    break;

                case 4:
                    Console.WriteLine($"Number is 4");
                    break;

                case 5:
                    Console.WriteLine($"Number is 5");
                    break;

                default:
                    Console.WriteLine($"Error ! Wrong number choosed");
                    break;
            }

            Console.ReadKey();
        }
    }
}
