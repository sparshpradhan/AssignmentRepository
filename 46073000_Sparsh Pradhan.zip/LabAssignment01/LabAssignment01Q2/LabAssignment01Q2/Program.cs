﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssignment01Q2
{
    class Program
    {
        static void Main(string[] args)
        {
            int res;
            Console.WriteLine($"Enter values of first and second :");
            int first = Convert.ToInt32(Console.ReadLine());
            int second = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine($"Enter your choice : 1.Add 2.Sub 3.Mul 4.Div 5.Mod");
            int op = Convert.ToInt32(Console.ReadLine());

            switch (op)
            {
                case 1:
                    res = first + second;
                    Console.WriteLine($"Addition is : {res}");
                    break;

                case 2:
                   res = first - second;
                    Console.WriteLine($"Substraction is : {res}");
                    break;

                case 3:
                    res = first * second;
                    Console.WriteLine($"Multiplication is : {res}");
                    break;

                case 4:
                    res = first / second;
                    Console.WriteLine($"Division is : {res}");
                    break;

                case 5:
                    res = first % second;
                    Console.WriteLine($"Modulus is : {res}");
                    break;

                default:
                    Console.WriteLine($"Wrong option");
                    break;
            }

            Console.ReadKey();
        }
    }
}
