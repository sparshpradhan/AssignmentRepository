﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Que01
{
    public class Customer
    {
        //Task 1
        private int customerId;
        private string customerName;
        private string address;
        private string city;
        private long phone;
        private double creditLimit;

        //Task 2
        public double CreditLimit
        {
            get { return creditLimit; }
            set { creditLimit = value; }
        }

        public long Phone
        {
            get { return phone; }
            set { phone = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        public int CustomerId
        {
            get { return customerId; }
            set { customerId = value; }
        }

        //Task 3
        public Customer()
        {

        }

        public Customer(int customerId, string customerName, string address, string city, long phone, double creditLimit)
        {
            this.CustomerId = customerId;
            this.CustomerName = customerName;
            this.Address = address;
            this.City = city;
            this.Phone = phone;
            this.CreditLimit = creditLimit;
        }
    }
}
