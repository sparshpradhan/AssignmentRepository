﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Que01
{
     class InvalidClassExp: Exception
    {
        public InvalidClassExp()
        {

        }

        public InvalidClassExp(string creditLimit) : base(creditLimit)
        {
            Console.WriteLine("Invalid credit limit!");
        }
    }
}
