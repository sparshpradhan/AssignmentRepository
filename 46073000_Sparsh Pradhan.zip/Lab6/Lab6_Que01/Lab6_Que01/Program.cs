﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Que01
{
    class Program
    {
        private static void ValidateCredit(Customer c)
        {

            if (c.CreditLimit > 50000)
            {
                throw new InvalidCreditLimitException(Convert.ToString(c.CreditLimit));
            }
            else
            {
                Console.WriteLine("Valid Credit limit!");
            }
        }

        static void Main(string[] args)
        {
            Customer c = null;

            try
            {
                c = new Customer()
                {
                    CustomerId = 101,
                    CustomerName = "Shweta",
                    Address = "Gottigere",
                    City = "Bangalore",
                    Phone = 9876543212L,
                    CreditLimit = 5000
                };

                ValidateCredit(c);
                   
            }

            catch (InvalidCreditLimitException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }
    }
}
