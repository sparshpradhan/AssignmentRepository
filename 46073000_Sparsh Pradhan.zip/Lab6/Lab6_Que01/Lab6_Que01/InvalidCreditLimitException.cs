﻿using System;
using System.Runtime.Serialization;

namespace Lab6_Que01
{
    [Serializable]
    internal class InvalidCreditLimitException : Exception
    {
        public InvalidCreditLimitException()
        {
        }

        public InvalidCreditLimitException(string message) : base(message)
        {
        }

        public InvalidCreditLimitException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected InvalidCreditLimitException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}