﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab6_Q2
{
    class Products
    {
        private int productId;

        public int ProductId
        {
            get { return productId; }
            set { productId = value; }
        }

        private string productName;

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        private double price;

        public double Price
        {
            get { return price; }
            set { price = value; }
        }

        public Products(int productId, string productName, double price)
        {
            this.ProductId = productId;
            this.ProductName = productName;
            this.Price = price;
        }

        public Products()
        {

        }
    }
}