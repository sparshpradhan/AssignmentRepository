﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Lab6_Q2
{
    class ProductTest
    {
        public static void GetProductDetails()
        {
        }

        public static void DisplayDetails(Products product)
        {
            Console.WriteLine("Product Details : ");
        }

        static void Main(string[] args)
        {
            Products product = null;
            try
            {
                DisplayDetails(product);

                product = new Products();
                Console.Write("Enter ID : ");
                product.ProductId = int.Parse(Console.ReadLine());
                Console.Write("Enter Product Name : ");
                product.ProductName = Console.ReadLine();
                Console.Write("Enter Product Price : ");
                product.Price = double.Parse(Console.ReadLine());

                ValidateProduct(product);
            }
            catch (DataEntryException ex)
            {
                Console.WriteLine(ex.Message);
            }

            Console.ReadKey();
        }

        private static void ValidateProduct(Products product)
        {
            Regex regex1 = new Regex("-[0-9]*");
            if (regex1.IsMatch(Convert.ToString(product.ProductId)))
            {
                Console.WriteLine("Product ID must be greater than zero!");
                throw new DataEntryException(Convert.ToString(product.ProductId));

            }

            Regex regex2 = new Regex("-[0-9]*");
            if (regex2.IsMatch(Convert.ToString(product.Price)))
            {
                Console.WriteLine("Price of product must be greater than zero!");
                throw new DataEntryException(Convert.ToString(product.Price));
            }

            if (String.IsNullOrEmpty(product.ProductName) == true)
            {
                Regex regex3 = new Regex("");
                if (regex3.IsMatch(product.ProductName))
                {
                    Console.WriteLine("Product Name cannot be left blank!");
                    throw new DataEntryException(product.ProductName);
                }
            }
            else
            {
                Regex regex4 = new Regex("[^A-Za-z0-9]*");
                if (regex4.IsMatch(product.ProductName))
                {
                    Console.WriteLine("Product Name should have alphabets and numbers only!");
                    throw new DataEntryException(product.ProductName);
                }
            }




        }
    }
}