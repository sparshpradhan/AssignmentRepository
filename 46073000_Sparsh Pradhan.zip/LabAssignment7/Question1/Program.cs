﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab7_Assignment;
using static System.Console;
using System.Collections;

namespace Lab7_Assignment
{
    public class Program
    {
        static void Main(string[] args)
        {
            
   
              var flag = 1;
              while (flag > 0)
              {
                WriteLine("Enter the choice : \n 1) AddContact\n 2) DisplayContact\n 3) EditContact \n 4) ShowAllContact \n 5) Exit");
                var choice = Convert.ToInt32(ReadLine());

                switch (choice)
                {
                    case 5:
                        flag = 0;
                        break;
                    case 1:
                        Contact.AddContact();
                        break;
                    case 2:
                        Contact.DisplayContact();
                        break;
                    case 3:
                        Contact.EditContact();
                        break;
                    case 4:
                        Contact.ShowAllContact();
                        break;
                    default:
                        WriteLine("Invalid choice");
                        break;
                }
             }
            ReadKey();
        }
    }
}
