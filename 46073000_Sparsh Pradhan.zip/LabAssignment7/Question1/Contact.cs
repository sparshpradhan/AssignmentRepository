﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.Collections;

namespace Lab7_Assignment
{
    public class Contact
    {
       

        static List<Contact> contactList = new List<Contact>();

        public int ContactNo;

        public string ContactName;

        public int CellNo;

        public static void AddContact()
        {
            WriteLine("Enter the ContactNo :");
            int contactNo = Convert.ToInt32(ReadLine());
            WriteLine("Enter the ContactName :");
            string contactName = ReadLine();
            WriteLine("Enter the CellNo :");
            int cellNo = Convert.ToInt32(ReadLine());

            contactList.Add(new Contact() { ContactNo = contactNo, ContactName = contactName, CellNo = cellNo });
        }

        public static void DisplayContact()
        {
            WriteLine("Enter the ContactNo whose details to be displayed :");
            int value = Convert.ToInt32(ReadLine());
            foreach (Contact c in contactList)
            {
                if (c.ContactNo == value)
                { 
                    WriteLine($"{c.ContactNo}, {c.ContactName}, {c.CellNo}");
                }
            }
        }
        public static void EditContact()
        {
            WriteLine("Enter the ContactNo whose details to be modified :");
            int value = Convert.ToInt32(ReadLine());
            //int count = 0; int index = value;
            foreach (Contact c in contactList)
            {
                if (c.ContactNo == value)
                WriteLine("Enter the ContactName:");
                string newName = ReadLine();
                WriteLine("Enter the CellNo:");
                int cellno = Convert.ToInt32(ReadLine());
                contactList.Find(p => p.ContactNo == value).ContactName = newName;
                contactList.Find(p => p.ContactNo == value).CellNo = cellno;
                //WriteLine($"{c.ContactNo}, {c.ContactName}, {c.CellNo}");
                //index = count; // I found a match and I want to edit the item at this index
                //count++;
            }
        }
        public static void ShowAllContact()
        {
            foreach (Contact c in contactList)
            {
                {
                    WriteLine($"{c.ContactNo}, {c.ContactName}, {c.CellNo}");
                }
            }
        }
     }
}