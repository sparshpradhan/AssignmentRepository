﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    public class Employee
    {
        public int EmpNo { get; set; }
        public string Name { get; set; }

        public double Salary { get; set; }

        public Double ProvidentFund { get; set; }

        public Employee()
        {
            EmpNo = default;
            Name = default;
            Salary = default;
            ProvidentFund = default;
        }

        public Employee(int eno, string name, double salary, double pf)
        {
            EmpNo = eno;
            Name = name;
            Salary = salary;
            ProvidentFund = pf;
        }
    }
}
