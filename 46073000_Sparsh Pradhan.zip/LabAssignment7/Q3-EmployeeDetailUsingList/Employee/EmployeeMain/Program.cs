﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using Employees;

namespace EmployeeMain
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Employee> li = new List<Employee>();
            int flag = 0;

            WriteLine("~Employee List~\n1. Add\n2. Search\n3. Delete\n4. Display\n5. Exit");

            while (true)
            {
                WriteLine("\nEnter your choice?");
                int choice = int.Parse(ReadLine());
                switch (choice)
                {
                    case 1: Add(li);
                        

                        break;

                    case 2: Search(li);

                        
                        break;

                    case 3: Delete(li);

                        break;

                    case 4: Display(li);



                       
                        break;

                    case 5:
                        flag = 1;
                        break;

                    default:
                        WriteLine("Invalid Input");
                        break;
                }
                if (flag == 1)
                    break;
            }



        }

        static void Add(List<Employee> li)
        {
            
            Write("Enter the Employee Details =>\nEmployee No. : ");
            int pno = int.Parse(ReadLine());

            Write("Name: ");
            string name = ReadLine();
            Write("Salary : ");
            double salary = double.Parse(ReadLine());
            Write("Provident Fund : ");
            double pf = double.Parse(ReadLine());
            Employee e = new Employee(pno, name, salary, pf);
            li.Add(e);

            
          
        }

        static void Search(List<Employee> li)
        {
            Write("Enter EmpNo of Employee to search : ");
            int eid = int.Parse(ReadLine());
            int f = 0;

            foreach (Employee obj in li)
            {
                if (obj.EmpNo == eid)
                {
                    WriteLine("_______________________________________________________________________");
                    WriteLine($"Employee No : {obj.EmpNo}, Name : {obj.Name}, Salary : {obj.Salary}, PF : {obj.ProvidentFund}");
                    WriteLine("_______________________________________________________________________");
                    f = 1;
                }



            }
            if (f == 0)
                WriteLine("Product not found!");
        }
        static void Display(List<Employee> li)
        {
            

                        foreach (Employee obj in li)
            {
                if (obj != null)
                {
                    WriteLine("____________________________________________________________________");
                    WriteLine($"Employee No : {obj.EmpNo}, Name : {obj.Name}, Salary : {obj.Salary}, PF : {obj.ProvidentFund}");
                    WriteLine("_______________________________________________________________________");
                }
            }
        }

        static void Delete(List<Employee> li)
        {
            Write("Enter ID of Employee to delete : ");
            int del_id = int.Parse(ReadLine());


            Employee obj = null;
            for (int i = 0; i < li.Count; i++)
            {
                if ((li[i] as Employee).EmpNo == del_id)
                {
                    obj = li[i] as Employee;
                    break;
                }
            }

            if (obj != null)
            {

                li.Remove(obj);
                WriteLine("Deleted!");

            }
        }
    }
}
