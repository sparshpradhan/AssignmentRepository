﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que2
{
    class Program
    {
        static void Main(string[] args)
        {
            //Lab4: Q2
            Shape s = new Shape();

            s = new Shape.Triangle();
            s.WhoAmI();

            s = new Shape.Circle();
            s.WhoAmI();

            Console.ReadKey();
        }
    }
}
