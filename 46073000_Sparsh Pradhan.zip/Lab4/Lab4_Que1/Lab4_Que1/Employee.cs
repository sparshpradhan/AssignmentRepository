﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{
    public abstract class Employee
    {
        public int EmpID;
        public string EmpNm;
        public string EmpAdd;
        public string EmpCity;
        public string EmpDept;
        public double EmpSal;

        public abstract void GetSal(double Sal);
    }
}
