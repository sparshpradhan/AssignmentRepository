﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{

    public class ContractEmployee : Employee
    {
        public double Perks = 1000;

        public override void GetSal(double Sal)
        {
            double TotSal = Sal + Perks;
            Console.WriteLine("Salary:" + TotSal);
        }
    }
    public class PermanentEmployee : Employee
    {
        public int NoOfLeaves;
        public double PF;

        public override void GetSal(double Sal)
        {
            PF = 6/50 * Sal;
            double TotSal1 = PF + Sal;
            Console.WriteLine("Salary:" + TotSal1);
        }
    }
}
