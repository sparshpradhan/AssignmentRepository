﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4_Que1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1.Contract Employee | 2.Permanent Employee || Enter your choice : ");
            int character = Convert.ToInt32(Console.ReadLine());

            switch (character)
            {
                case 1: //Contract Employee
                    ContractEmployee c = new ContractEmployee();

                    Console.WriteLine("Enter ID :");
                    c.EmpID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Name :");
                    c.EmpNm = Console.ReadLine();
                    Console.WriteLine("Enter Address :");
                    c.EmpAdd = Console.ReadLine();
                    Console.WriteLine("Enter City :");
                    c.EmpCity = Console.ReadLine();
                    Console.WriteLine("Enter Department :");
                    c.EmpDept = Console.ReadLine();
                    Console.WriteLine("Enter salary :");
                    c.EmpSal = Convert.ToInt32(Console.ReadLine());

                    c.GetSal(c.EmpSal);
                    break;

                case 2: //Permanent Employee
                    PermanentEmployee p = new PermanentEmployee();

                    Console.WriteLine("Enter ID :");
                    p.EmpID = Convert.ToInt32(Console.ReadLine());
                    Console.WriteLine("Enter Name :");
                    p.EmpNm = Console.ReadLine();
                    Console.WriteLine("Enter Address :");
                    p.EmpAdd = Console.ReadLine();
                    Console.WriteLine("Enter City :");
                    p.EmpCity = Console.ReadLine();
                    Console.WriteLine("Enter Department :");
                    p.EmpDept = Console.ReadLine();
                    Console.WriteLine("Enter Salary :");
                    p.EmpSal = Convert.ToInt32(Console.ReadLine());
                    p.GetSal(p.EmpSal);
                    break;

                default:
                    Console.WriteLine("Wrong choice !");
                    break;
            }

            Console.ReadKey();
        }
    }
}
