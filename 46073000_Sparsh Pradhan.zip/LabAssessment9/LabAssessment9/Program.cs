﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LabAssessment9
{
	class Program
	{
		static void Main()
		{
			// Task 1
			Dictionary<string, string> openWith = new Dictionary<string, string>();

			//Task 2 
			openWith.Add("One", "Red");
			openWith.Add("Two", "Green");
			openWith.Add("Three", "Yellow");
			openWith.Add("Four", "Blue");

			//Task 3 
			try
			{
				openWith.Add("Three", "Purple");
			}
			catch (ArgumentException)
			{
				Console.WriteLine("An element with Key = \"Three\" already exists.");
			}
			//Task 4 
			openWith["Four"] = "Orange";
			Console.WriteLine("For key = \"Four\", value = {0} ", openWith["Four"]);

			//Task 5
			openWith["Five"] = "White";

			//Task 6 
			try
			{
				Console.WriteLine("For key = \"Six\", value = {0} ",
					openWith["Six"]);
			}
			catch (KeyNotFoundException)
			{
				Console.WriteLine("Key = \"Six\" is not found.");
			}
			// Task 7 
			Console.WriteLine();
			foreach (KeyValuePair<string, string> kvp in openWith)
			{
				Console.WriteLine("Key = {0}, Value = {1}",
					kvp.Key, kvp.Value);
			}
			//Task 8 
			Console.WriteLine();
			Console.WriteLine("Element with Key : (\"Five\") is removed");
			openWith.Remove("Five");

			if (!openWith.ContainsKey("Five"))
			{
				Console.WriteLine("Key \"Five\" is not found.");
			}

			Console.WriteLine();
			foreach (KeyValuePair<string, string> kvp in openWith)
			{
				Console.WriteLine("Key = {0}, Value = {1}",
					kvp.Key, kvp.Value);
			}
			Console.ReadKey();
		}
	}
}
