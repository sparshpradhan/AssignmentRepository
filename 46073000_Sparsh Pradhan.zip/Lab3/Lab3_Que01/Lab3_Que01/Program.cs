﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que01
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("EmpId :");
            int EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Person Name : ");
            string name = Console.ReadLine();
            Console.WriteLine("Enter Company Name : ");
            string CompanyName = Console.ReadLine();
            Console.WriteLine("Enter Marks of Foundation : ");
            double FoundationMarks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Marks of WebBasics : ");
            double WebBasics = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Student DotNetMarks : ");
            double DotNetMarks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Student TotalMarks : ");
            double TotalMarks = Convert.ToDouble(Console.ReadLine());

            Participants p = new Participants(EmpId,  name, CompanyName,FoundationMarks,WebBasics,DotNetMarks,TotalMarks);
            
            p.calculate();
            p.Display();
            Console.ReadKey();

        }
    }
}
