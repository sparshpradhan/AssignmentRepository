﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que01
{
    class Participants
    {
        string name;
        int EmpId;
        string CompanyName;
        double FoundationMarks, WebBasics, DotNetMarks, TotalMarks, ObtainedMarks, Percentage;
        public void Getdata()
        {
            Console.WriteLine("Enter Person Name : ");
            name = Console.ReadLine();
            Console.WriteLine("EmpId :");
            EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Company Name : ");
            CompanyName = Console.ReadLine();
            Console.WriteLine("Enter Marks of Foundation : ");
            FoundationMarks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Marks of WebBasics : ");
            WebBasics = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Student DotNetMarks : ");
            DotNetMarks = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter Student TotalMarks : ");
            TotalMarks = Convert.ToDouble(Console.ReadLine());

        }

        public Participants(int _EmpId, string _Empname,  string _EmpCompanyName, double _EmpFoundationMarks, double _EmpWebBasics, double _EmpDotNetMarks, double _total)
        {
            EmpId = _EmpId ;
            name= _Empname ;
            CompanyName = _EmpCompanyName;
            FoundationMarks = _EmpFoundationMarks;
            WebBasics = _EmpWebBasics;
            DotNetMarks= _EmpDotNetMarks;
           TotalMarks = _total;


        }

        public void calculate()
        {
            ObtainedMarks = FoundationMarks + WebBasics + DotNetMarks;
            Percentage = (ObtainedMarks / TotalMarks) * 100;

        }

        public void Display()
        {
            Console.WriteLine("Name of Person is: {0}", name);
            Console.WriteLine("EmpId is : {0}", EmpId);
            Console.WriteLine("Obtained Marks : {0}", ObtainedMarks);
            Console.WriteLine("Percentage : {0}", Percentage);

        }

    }
}
