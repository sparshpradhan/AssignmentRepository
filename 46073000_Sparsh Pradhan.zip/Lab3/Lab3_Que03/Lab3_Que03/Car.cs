﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que03
{
    class Car
    {
        public string carMake;
        public string model;
        public int year;
        public double price;
        public Car()
        {
            
                Console.WriteLine("enter the carNAme");
                string carname = Console.ReadLine();
                Console.WriteLine("enter the carMake");
                carMake = Console.ReadLine();
                Console.WriteLine("enter the model");
                model = Console.ReadLine();
                Console.WriteLine("enter the year");
                year = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter the price");
                price = Convert.ToDouble(Console.ReadLine());



            

        }

    }
}
