﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que03
{
    class Program
    {
        static void Main(string[] args)
        {
            Car[] c = new Car[2];
            for (int i = 0; i < c.Length; i++)
            {
                c[i] = new Car();

            }

            Console.WriteLine("enter the  Catalog number");
            int m = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(c[m - 1].carMake);
            Console.WriteLine(c[m - 1].model);
            Console.WriteLine(c[m - 1].year);
            Console.WriteLine(c[m - 1].price);
            Console.WriteLine("list the all the catalog");

            for(int i=0;i<c.Length; i++)
            {
                Console.WriteLine(c[i].carMake + " " + c[i].model + " " + c[i].year + " " + c[i].price);

            }
            Console.WriteLine("which catalog what to delete specify the catalog number");
            int x = Convert.ToInt32(Console.ReadLine());
            
            int v = x - 1;
            for (int j = v; j < c.Length + 1; j++)
            {
                c[j] = c[j + 1];

            }


            for(int i = 0; i < c.Length - 1; i++)
            {
                Console.WriteLine(c[i].carMake + " " + c[i].model + " " + c[i].year + " " + c[i].price);
            }

           
            Console.ReadKey();










        }
    }
}
