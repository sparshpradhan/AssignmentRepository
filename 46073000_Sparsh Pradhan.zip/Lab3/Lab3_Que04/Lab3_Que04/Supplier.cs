﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3_Que04
{
    class Supplier
    {
        int SuplierId, PhoneNo;
        string SuplierName, City, Email;
        public void acceptdetails()
        {
            Console.WriteLine($"Enter Suplier ID : ");
            SuplierId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Suplier Name :");
            SuplierName = Console.ReadLine();
            Console.WriteLine("Enter Suplier City : ");
            City = Console.ReadLine();
            Console.WriteLine("Enter Suplier PhoneNo : ");
            PhoneNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Suplier Email : ");
            Email = Console.ReadLine();
            Console.ReadKey();

        }

        public void displaydetails()
        {
            Console.WriteLine($"Suplier Id is: {SuplierId}");
            Console.WriteLine($"Suplier Name is: {SuplierName}");
            Console.WriteLine($"Suplier City is: {City}");
            Console.WriteLine($"Suplier PhoneNois: {PhoneNo}");
            Console.WriteLine($"Suplier Email is: {Email}");

        }


    }
}
